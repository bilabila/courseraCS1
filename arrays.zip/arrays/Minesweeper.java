package arrays;

import java.util.Random;
/**
 *
 * @author AUGUSTO.BILABILA
 * @since Aug 23, 2023 | 8:30:14 PM
 */
public class Minesweeper {
    public static void main(String[] args) {
        int m = Integer.parseInt(args[0]);
        int n = Integer.parseInt(args[1]);
        int k = Integer.parseInt(args[2]);
        
        char[][] grid = new char[m][n];
        
        // Fill the grid with empty cells
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                grid[i][j] = '.';
            }
        }
        
        // Place mines randomly
        Random random = new Random();
        int minesPlaced = 0;
        while (minesPlaced < k) {
            int row = random.nextInt(m);
            int col = random.nextInt(n);
            
            if (grid[row][col] != '*') {
                grid[row][col] = '*';
                minesPlaced++;
            }
        }
        
        // Calculate neighboring mine counts
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (grid[i][j] == '.') {
                    int count = 0;
                    
                    // Check neighboring cells
                    for (int x = -1; x <= 1; x++) {
                        for (int y = -1; y <= 1; y++) {
                            if (x == 0 && y == 0) continue;
                            
                            int newRow = i + x;
                            int newCol = j + y;
                            
                            if (newRow >= 0 && newRow < m && newCol >= 0 && newCol < n) {
                                if (grid[newRow][newCol] == '*') {
                                    count++;
                                }
                            }
                        }
                    }
                    
                    grid[i][j] = (char) (count + '0');
                }
            }
        }
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                System.out.print(grid[i][j] + "  ");
            }
            System.out.println();
        }
    }

}
