
/**
 *
 * @author AUGUSTO.BILABILA
 * @since Aug 18, 2023 | 12:33:16 PM
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
