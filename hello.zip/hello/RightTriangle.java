
/**
 *
 * @author AUGUSTO.BILABILA
 * @since Aug 18, 2023 | 8:07:37 PM
 */
public class RightTriangle {

    public static void main(String[] args) {
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        int c = Integer.parseInt(args[2]);

        int hypotenuse = Math.max(Math.max(a, b), c);
        int threeSquare = (int) (Math.pow(hypotenuse, 2));
        int sumOfSquares = (int) (Math.pow(a, 2) + Math.pow(b, 2) + Math.pow(c, 2)) - (threeSquare);

        System.out.println(sumOfSquares == threeSquare);
    }

}
