
/**
 *
 * @author AUGUSTO.BILABILA
 * @since Aug 18, 2023 | 9:36:52 PM
 */
public class GreatCircle {

    public static void main(String[] args) {

        double x1 = Math.toRadians(Double.parseDouble(args[0]));
        double y1 = Math.toRadians(Double.parseDouble(args[1]));
        double x2 = Math.toRadians(Double.parseDouble(args[2]));
        double y2 = Math.toRadians(Double.parseDouble(args[3]));

        double yChange = (y2 - y1) / 2.0;
        double secondTerm = Math.cos(x1) * Math.cos(x2) * Math.sin(yChange) * Math.sin(yChange);
        double xChange = (x2 - x1) / 2.0;
        double firstTerm = Math.sin(xChange) * Math.sin(xChange);
        double operand = Math.sqrt(firstTerm + secondTerm);
       System.out.println(2.0 * 6371.0 * Math.asin(operand) + " kilometers");
       
        
    }
}
