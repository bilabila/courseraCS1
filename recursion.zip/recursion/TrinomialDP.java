
/**
 *
 * @author AUGUSTO.BILABILA
 * @since Aug 30, 2023 | 6:40:02 PM
 */
public class TrinomialDP {

    // Returns the trinomial coefficient T(n, k).
    public static long trinomial(int n, int k) {
        if (k < -n || k > n) {
            return 0; // Return 0 for invalid values of k
        }

        long[][] dp = new long[n + 1][2 * n + 2];

        dp[0][n] = 1;

        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= 2 * n; j++) {
                dp[i][j] = dp[i - 1][j];
                if (j > 0) {
                    dp[i][j] += dp[i - 1][j - 1];
                }
                if (j < 2 * n) {
                    dp[i][j] += dp[i - 1][j + 1];
                }
            }
        }

        return dp[n][k + n];
    }

    // Takes two integer command-line arguments n and k and prints T(n, k).
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int k = Integer.parseInt(args[1]);

        System.out.println(trinomial(n, k));
    }
}
