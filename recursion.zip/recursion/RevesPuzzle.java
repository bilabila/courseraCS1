/**
 *
 * @author AUGUSTO.BILABILA
 * @since Aug 31, 2023 | 10:43:32 AM
 */
public class RevesPuzzle {

   public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        
        char source = 'A';
        char destination = 'D';
        char auxiliary1 = 'B';
        char auxiliary2 = 'C';

        solve(n, source, destination, auxiliary1, auxiliary2);
    }

   private static void solve(int n, char source, char destination, char auxiliary1, char auxiliary2) {
    // Base case.
    if (n == 0) {
        return;
    }

    // Move the top n - 1 discs from source to auxiliary2.
    solve(n - 1, source, auxiliary2, destination, auxiliary1);

    // Move the bottom disc from source to destination.
    System.out.println("Move disc " + n + " from " + source + " to " + destination);

    // Move the top n - 1 discs from auxiliary2 to destination.
    solve(n - 1, auxiliary2, destination, source, auxiliary1);
}
}
