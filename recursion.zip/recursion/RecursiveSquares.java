
/**
 *
 * @author AUGUSTO.BILABILA
 * @since Aug 31, 2023 | 11:26:06 AM
 */
public class RecursiveSquares {

    public static void drawSquare(double x, double y, double sideLength) {

        StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
        StdDraw.filledSquare(x, y, sideLength / 2);
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.square(x, y, sideLength / 2);

    }

    public static void draw(int n, double x, double y, double sideLength) {
        if (n == 0) {
            return;
        }

        // Draw a square centered at (x, y) with the given side length
        double halfSide = sideLength / 2;
        double left = x - halfSide;
        double bottom = y - halfSide;

        drawSquare(x, y, sideLength);
//        StdDraw.square(left + halfSide, bottom + halfSide, halfSide);
        // Recursively draw smaller squares in the corners of the current square
        draw(n - 1, left, bottom, halfSide);
        draw(n - 1, left + sideLength, bottom, halfSide);
        draw(n - 1, left + sideLength, bottom + sideLength, halfSide);
        draw(n - 1, left, bottom + sideLength, halfSide);
    }

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        draw(n, 0.5, 0.5, 0.5);
    }
}
