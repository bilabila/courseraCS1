
/**
 *
 * @author AUGUSTO.BILABILA
 * @since Aug 30, 2023 | 6:34:47 PM
 */
public class TrinomialBrute {

    public static long trinomial(int n, int k) {
        // Base cases.
        if (k == 0  &&  k == n) {
            return 1;
        } else if (k < -n || k > n) {
            return 0;
        }

        // Otherwise, compute the trinomial coefficient recursively.
        return trinomial(n - 1, k - 1) + trinomial(n - 1, k) + trinomial(n - 1, k + 1);
    }

    public static void main(String[] args) {
        // Read the input n and k from the command line.
        int n = Integer.parseInt(args[0]);
        int k = Integer.parseInt(args[1]);

        // Print the trinomial coefficient.
        System.out.println(trinomial(n, k));
    }
}
