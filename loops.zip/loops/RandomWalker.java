package loops;


/**
 *
 * @author AUGUSTO.BILABILA
 * @since Aug 20, 2023 | 11:05:52 PM
 */
public class RandomWalker {

    public static void main(String[] args) {
        int r = Integer.parseInt(args[0]);
        int x = 0;
        int y = 0;
        int steps = 0;
        System.out.println("(" + x + ", " + y + ")");
        while (Math.abs(x) + Math.abs(y) < r) {
            double i = Math.random();
            if (i < 0.25) {
                x = x + 1;
                System.out.println("(" + x + ", " + y + ")");
                steps++;
            } else if (i < 0.5 && i >= 0.25) {
                x = x - 1;
                System.out.println("(" + x + ", " + y + ")");
                steps++;
            } else if (i < 0.75 && i >= 0.5) {
                y = y + 1;
                System.out.println("(" + x + ", " + y + ")");
                steps++;
            } else if (i >= 0.75) {
                y = y - 1;
                System.out.println("(" + x + ", " + y + ")");
                steps++;

            } else {
                break;
            }

        }
        System.out.println("steps = " + steps);
    }
}
